"""Shared utility helpers.

Reusable helper functions will be added as implementation needs emerge.
"""
