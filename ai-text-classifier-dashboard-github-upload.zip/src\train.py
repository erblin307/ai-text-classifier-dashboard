"""Model training pipeline for the AI text classifier."""

from pathlib import Path
import logging

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from src.config import (
    DEFAULT_LABEL_COLUMN,
    DEFAULT_TEXT_COLUMN,
    MODEL_PATH,
    PROCESSED_DATA_PATH,
    RANDOM_STATE,
    TEST_SIZE,
)
from src.data_loader import load_dataset, split_features_labels, validate_columns


logger = logging.getLogger(__name__)


def build_pipeline() -> Pipeline:
    """Build the TF-IDF and Logistic Regression training pipeline.

    Returns:
        An unfitted scikit-learn Pipeline.
    """
    return Pipeline(
        steps=[
            (
                "tfidf",
                TfidfVectorizer(
                    lowercase=False,
                    ngram_range=(1, 2),
                    min_df=1,
                    max_features=10000,
                ),
            ),
            (
                "classifier",
                LogisticRegression(
                    class_weight="balanced",
                    max_iter=1000,
                    random_state=RANDOM_STATE,
                ),
            ),
        ]
    )


def train_model(df: pd.DataFrame, text_column: str, label_column: str) -> Pipeline:
    """Train a text classification pipeline on a processed dataset.

    Args:
        df: Processed dataset containing text and labels.
        text_column: Name of the cleaned text column.
        label_column: Name of the target label column.

    Returns:
        A fitted scikit-learn Pipeline.

    Raises:
        ValueError: If the dataset does not contain enough rows or labels.
    """
    validate_columns(df, text_column, label_column)
    X, y = split_features_labels(df, text_column, label_column)
    _validate_training_data(X, y)

    stratify = _get_stratify_target(y)
    logger.info("Splitting dataset into train and test sets")
    X_train, _, y_train, _ = train_test_split(
        X,
        y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=stratify,
    )

    logger.info("Training model with %s training rows", len(X_train))
    model = build_pipeline()
    model.fit(X_train, y_train)
    logger.info("Training complete")
    return model


def save_model(model: Pipeline, path: Path) -> None:
    """Save a trained scikit-learn Pipeline to disk with joblib.

    Args:
        model: Fitted Pipeline to save.
        path: Destination path for the model artifact.

    Raises:
        RuntimeError: If the model cannot be saved.
    """
    model_path = Path(path)

    try:
        model_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(model, model_path)
    except OSError as exc:
        logger.exception("Could not save model to %s", model_path)
        raise RuntimeError(f"Could not save model to: {model_path}") from exc

    logger.info("Saved trained model to %s", model_path)


def main() -> None:
    """Load processed data, train the model, and save the fitted pipeline."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s:%(name)s:%(message)s")
    df = load_dataset(PROCESSED_DATA_PATH)
    model = train_model(df, DEFAULT_TEXT_COLUMN, DEFAULT_LABEL_COLUMN)
    save_model(model, MODEL_PATH)


def _validate_training_data(X: pd.Series, y: pd.Series) -> None:
    """Validate that the dataset is usable for supervised classification."""
    if X.empty or y.empty:
        raise ValueError("Training data cannot be empty.")

    label_count = y.nunique()
    if label_count < 2:
        raise ValueError("Training requires at least two unique labels.")

    if len(X) < 4:
        raise ValueError("Training requires at least four rows.")


def _get_stratify_target(y: pd.Series) -> pd.Series | None:
    """Return labels for stratified splitting when class counts allow it."""
    label_counts = y.value_counts()
    estimated_test_rows = max(1, round(len(y) * TEST_SIZE))

    if label_counts.min() < 2:
        logger.warning("Skipping stratified split because at least one class has one row")
        return None

    if estimated_test_rows < y.nunique():
        logger.warning("Skipping stratified split because the test split is too small")
        return None

    return y


if __name__ == "__main__":
    main()
