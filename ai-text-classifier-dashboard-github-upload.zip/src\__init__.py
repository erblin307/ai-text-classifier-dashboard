"""Source package for the AI Text Classifier Dashboard."""
