"""Project-wide configuration values.

This module centralizes paths and constants used across the NLP pipeline.
"""

from pathlib import Path


PROJECT_NAME = "ai-text-classifier-dashboard"
USE_CASE = "sentiment_analysis"
DATASET_NAME = "Custom review dataset"
MODEL_TYPE = "TF-IDF + Logistic Regression"
RANDOM_STATE = 42
TEST_SIZE = 0.2

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
SAMPLE_UPLOADS_DIR = DATA_DIR / "sample_uploads"
MODELS_DIR = PROJECT_ROOT / "models"
REPORTS_DIR = PROJECT_ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"

DEFAULT_TEXT_COLUMN = "text"
DEFAULT_LABEL_COLUMN = "label"

PROCESSED_DATA_PATH = PROCESSED_DATA_DIR / "processed_reviews.csv"
MODEL_PATH = MODELS_DIR / "text_classifier.joblib"
METRICS_PATH = REPORTS_DIR / "metrics.json"
CONFUSION_MATRIX_PATH = FIGURES_DIR / "confusion_matrix.png"
