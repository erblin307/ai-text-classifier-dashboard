"""Tests for prediction utilities."""

from pathlib import Path

import pandas as pd
import pytest
from sklearn.pipeline import Pipeline

from src.predict import load_model, predict_batch, predict_single_text
from src.train import save_model, train_model


@pytest.fixture()
def sample_training_data() -> pd.DataFrame:
    """Small sentiment dataset for fast unit tests."""
    return pd.DataFrame(
        {
            "text": [
                "great product love it",
                "excellent quality happy",
                "bad product hate it",
                "terrible quality disappointed",
                "okay product average",
                "fine but not special",
                "love this excellent item",
                "awful broken item",
                "average neutral purchase",
                "happy with product",
                "poor bad experience",
                "neutral acceptable item",
            ],
            "label": [
                "positive",
                "positive",
                "negative",
                "negative",
                "neutral",
                "neutral",
                "positive",
                "negative",
                "neutral",
                "positive",
                "negative",
                "neutral",
            ],
        }
    )


@pytest.fixture()
def trained_model(sample_training_data: pd.DataFrame) -> Pipeline:
    """Train a small model for prediction tests."""
    return train_model(sample_training_data, "text", "label")


def test_predict_single_text_returns_label_and_confidence(trained_model: Pipeline) -> None:
    """Single prediction should return label and confidence for Logistic Regression."""
    result = predict_single_text(trained_model, "Excellent product quality")

    assert result["input_text"] == "Excellent product quality"
    assert result["predicted_label"] in {"positive", "negative", "neutral"}
    assert 0 <= result["confidence_score"] <= 1


def test_predict_single_text_rejects_empty_input(trained_model: Pipeline) -> None:
    """Empty text after cleaning should raise a validation error."""
    with pytest.raises(ValueError, match="empty"):
        predict_single_text(trained_model, "https://example.com")


def test_predict_batch_returns_dataframe_and_skips_invalid_rows(
    trained_model: Pipeline,
) -> None:
    """Batch prediction should return a clean result table for valid rows."""
    upload_df = pd.DataFrame(
        {"review": ["I love this item", None, "Awful broken product"]}
    )

    predictions = predict_batch(trained_model, upload_df, "review")

    assert predictions.columns.tolist() == [
        "review",
        "predicted_label",
        "confidence_score",
    ]
    assert len(predictions) == 2


def test_predict_batch_raises_for_missing_text_column(trained_model: Pipeline) -> None:
    """A missing batch text column should raise a clear error."""
    upload_df = pd.DataFrame({"message": ["hello"]})

    with pytest.raises(ValueError, match="missing required column"):
        predict_batch(trained_model, upload_df, "review")


def test_load_model_round_trip(tmp_path: Path, trained_model: Pipeline) -> None:
    """Saved model artifacts should load back as Pipelines."""
    model_path = tmp_path / "model.joblib"

    save_model(trained_model, model_path)
    loaded_model = load_model(model_path)

    assert isinstance(loaded_model, Pipeline)


def test_load_model_raises_for_missing_file(tmp_path: Path) -> None:
    """Missing model paths should fail clearly."""
    with pytest.raises(FileNotFoundError):
        load_model(tmp_path / "missing.joblib")
