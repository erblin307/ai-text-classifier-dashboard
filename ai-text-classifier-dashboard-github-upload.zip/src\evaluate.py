"""Model evaluation utilities for trained text classifiers."""

from pathlib import Path
import json
import logging
from typing import Any

import joblib
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from src.config import (
    CONFUSION_MATRIX_PATH,
    DEFAULT_LABEL_COLUMN,
    DEFAULT_TEXT_COLUMN,
    METRICS_PATH,
    MODEL_PATH,
    PROCESSED_DATA_PATH,
    RANDOM_STATE,
    TEST_SIZE,
)
from src.data_loader import load_dataset, split_features_labels
from src.train import _get_stratify_target


logger = logging.getLogger(__name__)


def evaluate_model(model: Pipeline, X_test: pd.Series, y_test: pd.Series) -> dict[str, Any]:
    """Evaluate a trained classifier on held-out test data.

    Args:
        model: Fitted scikit-learn Pipeline.
        X_test: Text samples for evaluation.
        y_test: Ground-truth labels.

    Returns:
        JSON-serializable metrics calculated from real model predictions.

    Raises:
        ValueError: If test features or labels are empty.
    """
    if X_test.empty or y_test.empty:
        raise ValueError("Evaluation data cannot be empty.")

    logger.info("Evaluating model on %s test rows", len(X_test))
    y_pred = model.predict(X_test)
    labels = sorted(pd.Series(list(y_test) + list(y_pred)).astype(str).unique().tolist())

    metrics: dict[str, Any] = {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision_weighted": float(
            precision_score(y_test, y_pred, average="weighted", zero_division=0)
        ),
        "recall_weighted": float(
            recall_score(y_test, y_pred, average="weighted", zero_division=0)
        ),
        "f1_weighted": float(f1_score(y_test, y_pred, average="weighted", zero_division=0)),
        "labels": labels,
        "confusion_matrix": confusion_matrix(y_test, y_pred, labels=labels).tolist(),
        "classification_report": classification_report(
            y_test,
            y_pred,
            labels=labels,
            zero_division=0,
            output_dict=True,
        ),
    }

    logger.info("Evaluation complete with accuracy %.4f", metrics["accuracy"])
    return metrics


def save_metrics(metrics: dict, path: Path) -> None:
    """Save evaluation metrics to a JSON file.

    Args:
        metrics: JSON-serializable metrics dictionary.
        path: Destination JSON path.

    Raises:
        RuntimeError: If metrics cannot be saved.
    """
    metrics_path = Path(path)

    try:
        metrics_path.parent.mkdir(parents=True, exist_ok=True)
        metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    except OSError as exc:
        logger.exception("Could not save metrics to %s", metrics_path)
        raise RuntimeError(f"Could not save metrics to: {metrics_path}") from exc

    logger.info("Saved metrics to %s", metrics_path)


def plot_confusion_matrix(y_true, y_pred, output_path: Path) -> None:
    """Save a confusion matrix image for model evaluation.

    Args:
        y_true: Ground-truth labels.
        y_pred: Predicted labels.
        output_path: Destination image path.

    Raises:
        RuntimeError: If the image cannot be saved.
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError(
            "matplotlib is required to plot the confusion matrix. "
            "Install project dependencies with: pip install -r requirements.txt"
        ) from exc

    destination = Path(output_path)
    labels = sorted(pd.Series(list(y_true) + list(y_pred)).astype(str).unique().tolist())
    matrix = confusion_matrix(y_true, y_pred, labels=labels)

    fig, ax = plt.subplots(figsize=(8, 6))
    image = ax.imshow(matrix, interpolation="nearest", cmap="Blues")
    fig.colorbar(image, ax=ax)
    ax.set_title("Confusion Matrix")
    ax.set_xlabel("Predicted Label")
    ax.set_ylabel("True Label")
    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=45, ha="right")
    ax.set_yticklabels(labels)

    threshold = matrix.max() / 2 if matrix.size and matrix.max() else 0
    for row_index in range(matrix.shape[0]):
        for column_index in range(matrix.shape[1]):
            color = "white" if matrix[row_index, column_index] > threshold else "black"
            ax.text(
                column_index,
                row_index,
                matrix[row_index, column_index],
                ha="center",
                va="center",
                color=color,
            )

    fig.tight_layout()

    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(destination, dpi=150, bbox_inches="tight")
    except OSError as exc:
        logger.exception("Could not save confusion matrix to %s", destination)
        raise RuntimeError(f"Could not save confusion matrix to: {destination}") from exc
    finally:
        plt.close(fig)

    logger.info("Saved confusion matrix to %s", destination)


def main() -> None:
    """Evaluate the saved model against the held-out test split."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s:%(name)s:%(message)s")
    df = load_dataset(PROCESSED_DATA_PATH)
    X, y = split_features_labels(df, DEFAULT_TEXT_COLUMN, DEFAULT_LABEL_COLUMN)
    stratify = _get_stratify_target(y)

    _, X_test, _, y_test = train_test_split(
        X,
        y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=stratify,
    )

    model = _load_saved_model(MODEL_PATH)
    metrics = evaluate_model(model, X_test, y_test)
    y_pred = model.predict(X_test)
    save_metrics(metrics, METRICS_PATH)
    plot_confusion_matrix(y_test, y_pred, CONFUSION_MATRIX_PATH)


def _load_saved_model(path: Path) -> Pipeline:
    """Load a saved model artifact for evaluation."""
    model_path = Path(path)

    if not model_path.exists():
        raise FileNotFoundError(f"Model file not found: {model_path}")

    model = joblib.load(model_path)
    if not isinstance(model, Pipeline):
        raise TypeError(f"Expected a scikit-learn Pipeline, got {type(model).__name__}.")

    return model


if __name__ == "__main__":
    main()
