"""Text preprocessing utilities for an explainable TF-IDF pipeline."""

from pathlib import Path
import logging
import re
from typing import Any

import pandas as pd

from src.data_loader import validate_columns


logger = logging.getLogger(__name__)

URL_PATTERN = re.compile(r"https?://\S+|www\.\S+", flags=re.IGNORECASE)
EMAIL_PATTERN = re.compile(r"\b[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}\b")
HTML_PATTERN = re.compile(r"<[^>]+>")
SPECIAL_CHAR_PATTERN = re.compile(r"[^a-z0-9\s!?.,'-]")
WHITESPACE_PATTERN = re.compile(r"\s+")


def clean_text(text: str) -> str:
    """Clean a single text value while preserving useful sentiment cues.

    The cleaning is intentionally simple and explainable for TF-IDF:
    lowercase text, remove URLs, emails, HTML tags, unusual symbols, and
    normalize whitespace.

    Args:
        text: Raw text input.

    Returns:
        Cleaned text. Missing or non-string values become an empty string.
    """
    if not isinstance(text, str):
        return ""

    cleaned = text.lower()
    cleaned = URL_PATTERN.sub(" ", cleaned)
    cleaned = EMAIL_PATTERN.sub(" ", cleaned)
    cleaned = HTML_PATTERN.sub(" ", cleaned)
    cleaned = SPECIAL_CHAR_PATTERN.sub(" ", cleaned)
    cleaned = WHITESPACE_PATTERN.sub(" ", cleaned).strip()
    return cleaned


def preprocess_dataframe(
    df: pd.DataFrame, text_column: str, label_column: str
) -> pd.DataFrame:
    """Clean text data, remove unusable rows, and drop duplicates.

    Args:
        df: Raw dataset containing text and label columns.
        text_column: Name of the column containing text.
        label_column: Name of the column containing labels.

    Returns:
        A processed DataFrame with cleaned text and valid labels.

    Raises:
        ValueError: If required columns are missing or no valid rows remain.
    """
    validate_columns(df, text_column, label_column)
    logger.info("Starting preprocessing for %s rows", len(df))

    processed_df = df.copy()
    processed_df[text_column] = processed_df[text_column].apply(clean_text)
    processed_df[label_column] = processed_df[label_column].apply(_normalize_label)

    before_drop = len(processed_df)
    processed_df = processed_df[
        (processed_df[text_column] != "") & (processed_df[label_column] != "")
    ].copy()
    logger.info("Dropped %s rows with missing text or labels", before_drop - len(processed_df))

    before_dedup = len(processed_df)
    processed_df = processed_df.drop_duplicates(
        subset=[text_column, label_column], keep="first"
    ).reset_index(drop=True)
    logger.info("Removed %s duplicate rows", before_dedup - len(processed_df))

    if processed_df.empty:
        logger.error("No valid rows remain after preprocessing")
        raise ValueError("No valid rows remain after preprocessing.")

    logger.info("Finished preprocessing with %s rows", len(processed_df))
    return processed_df


def save_processed_data(df: pd.DataFrame, output_path: Path) -> None:
    """Save a processed DataFrame to CSV.

    Args:
        df: Processed dataset to save.
        output_path: Destination CSV path.

    Raises:
        ValueError: If the DataFrame is empty or the output is not a CSV file.
        RuntimeError: If the file cannot be written.
    """
    destination = Path(output_path)

    if df.empty:
        logger.error("Refusing to save an empty processed dataset")
        raise ValueError("Cannot save an empty processed dataset.")

    if destination.suffix.lower() != ".csv":
        logger.error("Processed data output must be a CSV file: %s", destination)
        raise ValueError(f"Processed data output must be a CSV file: {destination}")

    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(destination, index=False)
    except OSError as exc:
        logger.exception("Could not save processed data to %s", destination)
        raise RuntimeError(f"Could not save processed data to: {destination}") from exc

    logger.info("Saved processed data to %s", destination)


def _normalize_label(label: Any) -> str:
    """Convert label values to clean strings for downstream modeling."""
    if pd.isna(label):
        return ""
    return str(label).strip()
