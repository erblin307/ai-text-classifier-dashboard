"""Prediction utilities for single text and batch inputs."""

from pathlib import Path
import logging
from typing import Any

import joblib
import pandas as pd
from sklearn.pipeline import Pipeline

from src.preprocess import clean_text


logger = logging.getLogger(__name__)


def load_model(path: Path) -> Pipeline:
    """Load a saved scikit-learn Pipeline from disk.

    Args:
        path: Path to a joblib model artifact.

    Returns:
        A fitted scikit-learn Pipeline.

    Raises:
        FileNotFoundError: If the model artifact does not exist.
        TypeError: If the loaded object is not a scikit-learn Pipeline.
        RuntimeError: If the artifact cannot be loaded.
    """
    model_path = Path(path)

    if not model_path.exists():
        logger.error("Model file does not exist: %s", model_path)
        raise FileNotFoundError(f"Model file not found: {model_path}")

    try:
        model = joblib.load(model_path)
    except OSError as exc:
        logger.exception("Could not load model from %s", model_path)
        raise RuntimeError(f"Could not load model from: {model_path}") from exc

    if not isinstance(model, Pipeline):
        logger.error("Loaded object is not a Pipeline: %s", type(model).__name__)
        raise TypeError(f"Expected a scikit-learn Pipeline, got {type(model).__name__}.")

    logger.info("Loaded model from %s", model_path)
    return model


def predict_single_text(model: Pipeline, text: str) -> dict[str, Any]:
    """Predict the label and confidence for one text input.

    Args:
        model: Fitted scikit-learn Pipeline.
        text: Raw input text.

    Returns:
        Dictionary with input text, predicted label, and confidence score when available.

    Raises:
        ValueError: If the text is empty after cleaning.
    """
    cleaned_text = clean_text(text)
    if not cleaned_text:
        raise ValueError("Input text is empty after cleaning.")

    predicted_label = model.predict([cleaned_text])[0]
    result: dict[str, Any] = {
        "input_text": text,
        "cleaned_text": cleaned_text,
        "predicted_label": predicted_label,
    }

    confidence_score = _predict_confidence(model, [cleaned_text])
    if confidence_score is not None:
        result["confidence_score"] = confidence_score[0]

    logger.info("Predicted label '%s' for single text input", predicted_label)
    return result


def predict_batch(model: Pipeline, df: pd.DataFrame, text_column: str) -> pd.DataFrame:
    """Predict labels for a DataFrame of text rows.

    Args:
        model: Fitted scikit-learn Pipeline.
        df: Input DataFrame uploaded by a user.
        text_column: Name of the column containing raw text.

    Returns:
        DataFrame containing the original text column, predicted labels, and confidence
        scores when supported by the model.

    Raises:
        ValueError: If the text column is missing or no valid rows remain after cleaning.
    """
    _validate_text_column(df, text_column)
    logger.info("Running batch prediction for %s rows", len(df))

    results_df = df[[text_column]].copy()
    cleaned_text = results_df[text_column].apply(clean_text)
    valid_mask = cleaned_text != ""

    if not valid_mask.any():
        raise ValueError("No valid text rows remain after cleaning.")

    results_df = results_df.loc[valid_mask].copy()
    cleaned_text = cleaned_text.loc[valid_mask]
    predictions = model.predict(cleaned_text)

    results_df["predicted_label"] = predictions
    confidence_scores = _predict_confidence(model, cleaned_text.tolist())
    if confidence_scores is not None:
        results_df["confidence_score"] = confidence_scores

    logger.info("Completed batch prediction for %s valid rows", len(results_df))
    return results_df.reset_index(drop=True)


def _predict_confidence(model: Pipeline, texts: list[str]) -> list[float] | None:
    """Return max predicted probabilities when the classifier supports them."""
    if not hasattr(model, "predict_proba"):
        return None

    try:
        probabilities = model.predict_proba(texts)
    except AttributeError:
        return None

    return probabilities.max(axis=1).round(4).tolist()


def _validate_text_column(df: pd.DataFrame, text_column: str) -> None:
    """Validate that batch input contains the selected text column."""
    if df.empty:
        raise ValueError("Uploaded data is empty.")

    if text_column not in df.columns:
        raise ValueError(
            "Dataset is missing required column(s): "
            f"{text_column}. Available columns: {', '.join(df.columns)}"
        )
