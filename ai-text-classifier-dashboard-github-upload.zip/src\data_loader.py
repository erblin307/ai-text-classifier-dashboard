"""Data loading utilities for CSV-based text classification datasets."""

from pathlib import Path
import logging

import pandas as pd


logger = logging.getLogger(__name__)


def load_dataset(path: Path) -> pd.DataFrame:
    """Load a CSV dataset from disk.

    Args:
        path: Path to a CSV file, usually inside ``data/raw/``.

    Returns:
        A pandas DataFrame containing the loaded dataset.

    Raises:
        FileNotFoundError: If the CSV file does not exist.
        ValueError: If the path is not a CSV file or the loaded file is empty.
        RuntimeError: If pandas cannot read the CSV file.
    """
    csv_path = Path(path)
    logger.info("Loading dataset from %s", csv_path)

    if not csv_path.exists():
        logger.error("Dataset file does not exist: %s", csv_path)
        raise FileNotFoundError(f"Dataset file not found: {csv_path}")

    if not csv_path.is_file():
        logger.error("Dataset path is not a file: %s", csv_path)
        raise ValueError(f"Dataset path is not a file: {csv_path}")

    if csv_path.suffix.lower() != ".csv":
        logger.error("Dataset must be a CSV file: %s", csv_path)
        raise ValueError(f"Dataset must be a CSV file: {csv_path}")

    try:
        df = pd.read_csv(csv_path)
    except pd.errors.EmptyDataError as exc:
        logger.exception("Dataset file is empty: %s", csv_path)
        raise ValueError(f"Dataset file is empty: {csv_path}") from exc
    except pd.errors.ParserError as exc:
        logger.exception("Dataset file could not be parsed: %s", csv_path)
        raise RuntimeError(f"Could not parse CSV dataset: {csv_path}") from exc
    except OSError as exc:
        logger.exception("Dataset file could not be read: %s", csv_path)
        raise RuntimeError(f"Could not read dataset file: {csv_path}") from exc

    if df.empty:
        logger.error("Dataset loaded successfully but contains no rows: %s", csv_path)
        raise ValueError(f"Dataset contains no rows: {csv_path}")

    logger.info("Loaded dataset with %s rows and %s columns", len(df), len(df.columns))
    return df


def validate_columns(df: pd.DataFrame, text_column: str, label_column: str) -> None:
    """Validate that a DataFrame contains the required text and label columns.

    Args:
        df: Dataset to validate.
        text_column: Name of the column containing raw text.
        label_column: Name of the column containing class labels.

    Raises:
        ValueError: If the DataFrame is empty or required columns are missing.
    """
    if df.empty:
        logger.error("Cannot validate an empty DataFrame")
        raise ValueError("Dataset is empty.")

    required_columns = {text_column, label_column}
    existing_columns = set(df.columns)
    missing_columns = sorted(required_columns - existing_columns)

    if missing_columns:
        logger.error("Missing required columns: %s", missing_columns)
        raise ValueError(
            "Dataset is missing required column(s): "
            f"{', '.join(missing_columns)}. Available columns: {', '.join(df.columns)}"
        )

    logger.info("Validated required columns: text=%s, label=%s", text_column, label_column)


def split_features_labels(
    df: pd.DataFrame, text_column: str, label_column: str
) -> tuple[pd.Series, pd.Series]:
    """Split a validated DataFrame into text features and labels.

    Args:
        df: Dataset containing text and label columns.
        text_column: Name of the column containing raw text.
        label_column: Name of the column containing class labels.

    Returns:
        A tuple containing the text Series and label Series.

    Raises:
        ValueError: If required columns are missing.
    """
    validate_columns(df, text_column, label_column)
    logger.info("Splitting features and labels")
    return df[text_column], df[label_column]
