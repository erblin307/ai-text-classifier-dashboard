# Data Sources

## Selected Use Case

Sentiment analysis for customer and product reviews.

The project is designed around review or feedback text with labels such as:

- `positive`
- `neutral`
- `negative`

## Recommended Public Dataset Options

Use a public dataset that can be downloaded legally and used in a portfolio project. Good beginner-friendly options include:

- IMDb movie reviews dataset
- Amazon product reviews datasets
- Yelp review datasets
- Sentiment140
- Public customer review CSV datasets from academic or open-data repositories

Prefer datasets that are available through a direct download URL or a clearly documented source. If using Kaggle, document the Kaggle page and any manual download steps.

## Expected CSV Format

The modeling code expects a CSV file with:

```text
text,label
"The product quality is excellent","positive"
"Shipping was okay but packaging was damaged","neutral"
"The item broke after one day","negative"
```

Default column names are configured in [src/config.py](src/config.py):

```python
DEFAULT_TEXT_COLUMN = "text"
DEFAULT_LABEL_COLUMN = "label"
```

If your dataset uses different column names, pass those names to the loader and preprocessing functions.

## Folder Usage

```text
data/raw/              Original downloaded CSV files
data/processed/        Cleaned model-ready CSV files
data/sample_uploads/   Small user-upload examples for dashboard demos
```

Large datasets should not be committed to GitHub. The repository keeps the folders with `.gitkeep` files and ignores large raw, processed, and model artifacts.

## Preparation Workflow

1. Download a public sentiment dataset.
2. Place the raw CSV in `data/raw/`.
3. Identify the text and label columns.
4. Preprocess and save a clean CSV:

```bash
python -c "from pathlib import Path; from src.data_loader import load_dataset; from src.preprocess import preprocess_dataframe, save_processed_data; df = load_dataset(Path('data/raw/your_dataset.csv')); processed = preprocess_dataframe(df, 'text', 'label'); save_processed_data(processed, Path('data/processed/processed_reviews.csv'))"
```

5. Train the model:

```bash
python -m src.train
```

6. Evaluate the model:

```bash
python -m src.evaluate
```

## Dataset Documentation Checklist

When adding a real dataset, document:

- Dataset name
- Source URL
- License or usage terms
- Download date
- Original text column
- Original label column
- Any label mapping performed
- Number of rows after preprocessing

## Current Repository State

No large external dataset is committed to this repository. This is intentional so the project remains lightweight and avoids unclear data licensing.
