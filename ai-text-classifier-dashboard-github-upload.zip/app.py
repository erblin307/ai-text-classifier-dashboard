"""Streamlit dashboard for the AI Text Classifier project."""

from __future__ import annotations

import json
from html import escape
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st

from src.config import (
    CONFUSION_MATRIX_PATH,
    DATASET_NAME,
    METRICS_PATH,
    MODEL_PATH,
    MODEL_TYPE,
    PROJECT_NAME,
)
from src.explain import explain_prediction, get_top_features
from src.predict import load_model, predict_batch, predict_single_text


st.set_page_config(
    page_title="AI Text Classifier Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)


@st.cache_resource(show_spinner=False)
def get_model(model_path: Path):
    """Load and cache the trained model for dashboard predictions."""
    return load_model(model_path)


@st.cache_data(show_spinner=False)
def load_metrics(metrics_path: Path) -> dict[str, Any]:
    """Load saved evaluation metrics when available."""
    if not metrics_path.exists():
        return {}

    try:
        return json.loads(metrics_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def main() -> None:
    """Run the Streamlit dashboard."""
    inject_styles()
    render_sidebar()

    model = load_dashboard_model()
    metrics = load_metrics(METRICS_PATH)
    render_header(model, metrics)

    tab_single, tab_batch, tab_performance, tab_explainability, tab_business = st.tabs(
        [
            "Single Prediction",
            "Batch CSV",
            "Performance",
            "Explainability",
            "Client Use Cases",
        ]
    )

    with tab_single:
        render_single_prediction(model)

    with tab_batch:
        render_batch_prediction(model)

    with tab_performance:
        render_model_performance(metrics)

    with tab_explainability:
        render_explainability(model)

    with tab_business:
        render_business_use_case()


def inject_styles() -> None:
    """Inject dashboard-level CSS for a polished product interface."""
    st.markdown(
        """
        <style>
        :root {
            --bg: #f6f8fb;
            --surface: #ffffff;
            --surface-soft: #f9fafc;
            --text: #172033;
            --muted: #667085;
            --line: #d8dee8;
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --success: #067647;
            --warning: #b54708;
            --danger: #b42318;
            --shadow: 0 18px 45px rgba(16, 24, 40, 0.08);
            --radius: 8px;
        }

        .stApp {
            background:
                radial-gradient(circle at 10% 0%, rgba(37, 99, 235, 0.08), transparent 28rem),
                linear-gradient(180deg, #f8fafc 0%, var(--bg) 42%, #eef2f7 100%);
            color: var(--text);
        }

        section[data-testid="stSidebar"] {
            background: #111827;
            border-right: 1px solid rgba(255, 255, 255, 0.08);
        }

        section[data-testid="stSidebar"] * {
            color: #e5e7eb;
        }

        section[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p {
            color: #cbd5e1;
        }

        .block-container {
            max-width: 1240px;
            padding-top: 2rem;
            padding-bottom: 3rem;
        }

        h1, h2, h3 {
            color: var(--text);
            letter-spacing: 0;
        }

        h1 {
            font-size: 2.25rem;
            line-height: 1.12;
        }

        h2 {
            font-size: 1.35rem;
        }

        h3 {
            font-size: 1.05rem;
        }

        .hero {
            background: linear-gradient(135deg, #ffffff 0%, #f7fbff 55%, #eef6ff 100%);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1.5rem;
            margin-bottom: 1.25rem;
        }

        .eyebrow {
            color: var(--primary);
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0;
            margin-bottom: 0.35rem;
            text-transform: uppercase;
        }

        .hero-title {
            color: var(--text);
            font-size: 2.3rem;
            font-weight: 760;
            line-height: 1.08;
            margin: 0;
        }

        .hero-copy {
            color: var(--muted);
            font-size: 1rem;
            line-height: 1.65;
            margin: 0.75rem 0 0;
            max-width: 720px;
        }

        .status-row {
            display: flex;
            flex-wrap: wrap;
            gap: 0.6rem;
            margin-top: 1.1rem;
        }

        .pill {
            align-items: center;
            background: #eef2ff;
            border: 1px solid #c7d2fe;
            border-radius: 999px;
            color: #3730a3;
            display: inline-flex;
            font-size: 0.83rem;
            font-weight: 650;
            gap: 0.45rem;
            padding: 0.42rem 0.72rem;
            white-space: nowrap;
        }

        .pill.success {
            background: #ecfdf3;
            border-color: #abefc6;
            color: var(--success);
        }

        .pill.warning {
            background: #fffaeb;
            border-color: #fedf89;
            color: var(--warning);
        }

        .panel {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            box-shadow: 0 10px 30px rgba(16, 24, 40, 0.06);
            padding: 1.15rem;
            margin: 1rem 0;
        }

        .section-label {
            color: var(--primary);
            font-size: 0.76rem;
            font-weight: 750;
            letter-spacing: 0;
            margin-bottom: 0.2rem;
            text-transform: uppercase;
        }

        .section-title {
            color: var(--text);
            font-size: 1.35rem;
            font-weight: 740;
            line-height: 1.25;
            margin: 0;
        }

        .section-copy {
            color: var(--muted);
            font-size: 0.95rem;
            line-height: 1.58;
            margin: 0.45rem 0 0;
        }

        .empty-state {
            background: var(--surface-soft);
            border: 1px dashed #b8c2d3;
            border-radius: var(--radius);
            color: var(--muted);
            line-height: 1.55;
            margin-top: 0.85rem;
            padding: 1rem;
        }

        .result-card {
            background: #0f172a;
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            color: #ffffff;
            padding: 1rem;
        }

        .result-label {
            color: #cbd5e1;
            font-size: 0.78rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .result-value {
            color: #ffffff;
            font-size: 1.75rem;
            font-weight: 780;
            line-height: 1.15;
            margin-top: 0.2rem;
            word-break: break-word;
        }

        div[data-testid="stMetric"] {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            box-shadow: 0 8px 24px rgba(16, 24, 40, 0.05);
            padding: 0.9rem 1rem;
        }

        div[data-testid="stMetricLabel"] p {
            color: var(--muted);
            font-weight: 650;
        }

        .stTabs [data-baseweb="tab-list"] {
            background: rgba(255, 255, 255, 0.72);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            box-shadow: 0 8px 24px rgba(16, 24, 40, 0.05);
            gap: 0.2rem;
            padding: 0.35rem;
        }

        .stTabs [data-baseweb="tab"] {
            border-radius: 6px;
            color: #344054;
            font-weight: 700;
            padding: 0.6rem 0.85rem;
        }

        .stTabs [data-baseweb="tab"] p {
            color: #344054;
            font-weight: 700;
        }

        .stTabs [aria-selected="true"] {
            background: #ffffff;
            box-shadow: 0 4px 14px rgba(16, 24, 40, 0.08);
        }

        .stTabs [aria-selected="true"] p {
            color: var(--primary);
        }

        .stButton > button,
        .stDownloadButton > button {
            border-radius: var(--radius);
            font-weight: 700;
            min-height: 2.75rem;
            transition: all 150ms ease;
        }

        .stButton > button:hover,
        .stDownloadButton > button:hover {
            border-color: var(--primary);
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.18);
            transform: translateY(-1px);
        }

        textarea,
        input,
        div[data-baseweb="select"] > div {
            border-radius: var(--radius) !important;
        }

        [data-testid="stFileUploader"] {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            box-shadow: 0 8px 24px rgba(16, 24, 40, 0.05);
            padding: 1rem;
        }

        [data-testid="stFileUploader"] label,
        [data-testid="stFileUploader"] p,
        [data-testid="stFileUploader"] small,
        [data-testid="stFileUploader"] span {
            color: #344054 !important;
        }

        [data-testid="stFileUploaderDropzone"] {
            background: #f8fafc;
            border: 1px dashed #98a2b3;
            border-radius: var(--radius);
        }

        [data-testid="stFileUploaderDropzone"] button {
            background: #ffffff;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            color: var(--text);
            font-weight: 700;
        }

        [data-testid="stFileUploaderDropzone"] button:hover {
            border-color: var(--primary);
            color: var(--primary);
        }

        div[data-testid="stDataFrame"] {
            border: 1px solid var(--line);
            border-radius: var(--radius);
            overflow: hidden;
        }

        .use-case-grid {
            display: grid;
            gap: 0.85rem;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            margin-top: 1rem;
        }

        .use-case-card {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            box-shadow: 0 8px 24px rgba(16, 24, 40, 0.05);
            min-height: 128px;
            padding: 1rem;
        }

        .use-case-card strong {
            color: var(--text);
            display: block;
            font-size: 0.98rem;
            margin-bottom: 0.45rem;
        }

        .use-case-card span {
            color: var(--muted);
            font-size: 0.9rem;
            line-height: 1.5;
        }

        @media (max-width: 900px) {
            .block-container {
                padding-left: 1rem;
                padding-right: 1rem;
            }

            .hero {
                padding: 1rem;
            }

            .hero-title {
                font-size: 1.7rem;
            }

            .use-case-grid {
                grid-template-columns: 1fr;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_header(model, metrics: dict[str, Any]) -> None:
    """Render the dashboard hero and operational status chips."""
    model_status = "Model ready" if model is not None else "Model missing"
    metrics_status = (
        "Metrics ready"
        if metrics and metrics.get("status") != "not_evaluated"
        else "Metrics pending"
    )
    model_class = "success" if model is not None else "warning"
    metrics_class = (
        "success"
        if metrics and metrics.get("status") != "not_evaluated"
        else "warning"
    )

    st.markdown(
        f"""
        <div class="hero">
            <div class="eyebrow">Customer intelligence workspace</div>
            <h1 class="hero-title">AI Text Classifier Dashboard</h1>
            <p class="hero-copy">
                Classify reviews and messages, review model confidence, inspect
                performance, and explain predictions with a fast TF-IDF and
                scikit-learn workflow.
            </p>
            <div class="status-row">
                <span class="pill {model_class}">{model_status}</span>
                <span class="pill {metrics_class}">{metrics_status}</span>
                <span class="pill">TF-IDF pipeline</span>
                <span class="pill">CSV batch workflow</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_sidebar() -> None:
    """Render dashboard metadata and compact instructions."""
    st.sidebar.markdown("## AI Text Classifier")
    st.sidebar.caption("Business-ready NLP dashboard")
    st.sidebar.divider()
    st.sidebar.markdown(f"**Model**  \n{MODEL_TYPE}")
    st.sidebar.markdown(f"**Dataset**  \n{DATASET_NAME}")
    st.sidebar.markdown(f"**Project**  \n`{PROJECT_NAME}`")
    st.sidebar.divider()
    st.sidebar.markdown("### Workflow")
    st.sidebar.markdown("1. Add a CSV dataset.")
    st.sidebar.markdown("2. Run `python -m src.train`.")
    st.sidebar.markdown("3. Run `python -m src.evaluate`.")
    st.sidebar.markdown("4. Predict text or upload CSVs.")


def load_dashboard_model():
    """Load the model and show a friendly message if it is unavailable."""
    try:
        return get_model(MODEL_PATH)
    except FileNotFoundError:
        st.markdown(
            """
            <div class="empty-state">
                <strong>No trained model found.</strong><br>
                Train the model with <code>python -m src.train</code> before running predictions.
            </div>
            """,
            unsafe_allow_html=True,
        )
    except (RuntimeError, TypeError) as exc:
        st.error(f"Could not load the trained model: {exc}")

    return None


def render_section_header(label: str, title: str, copy: str) -> None:
    """Render a consistent section heading."""
    st.markdown(
        f"""
        <div class="panel">
            <div class="section-label">{escape(label)}</div>
            <h2 class="section-title">{escape(title)}</h2>
            <p class="section-copy">{escape(copy)}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_single_prediction(model) -> None:
    """Render the single-text prediction workflow."""
    render_section_header(
        "Manual analysis",
        "Single Text Prediction",
        "Paste one customer review or message to classify it instantly and inspect the explanation.",
    )

    input_column, guide_column = st.columns([2.1, 1], gap="large")
    with input_column:
        text = st.text_area(
            "Text to classify",
            height=190,
            placeholder="Paste a customer review, support message, or product comment...",
            label_visibility="collapsed",
        )
        predict_clicked = st.button(
            "Predict Text",
            type="primary",
            disabled=model is None,
            use_container_width=True,
        )

    with guide_column:
        st.markdown(
            """
            <div class="panel">
                <div class="section-label">Input tips</div>
                <p class="section-copy">
                    Use natural customer language. Longer reviews usually give the
                    TF-IDF model more signal than one-word messages.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    if not predict_clicked:
        return

    if model is None:
        st.error("Train and save a model before running predictions.")
        return

    try:
        result = predict_single_text(model, text)
    except ValueError as exc:
        st.error(str(exc))
        return

    label_column, confidence_column = st.columns(2, gap="medium")
    with label_column:
        render_result_card("Predicted label", str(result["predicted_label"]))
    with confidence_column:
        confidence = (
            f"{result['confidence_score']:.2%}"
            if "confidence_score" in result
            else "Not available"
        )
        render_result_card("Confidence score", confidence)

    st.markdown("### Cleaned Text")
    st.code(result["cleaned_text"], language="text")

    try:
        explanation = explain_prediction(model, text)
        st.markdown("### Prediction Explanation")
        st.dataframe(explanation, use_container_width=True, hide_index=True)
    except (TypeError, ValueError) as exc:
        st.info(f"Explanation unavailable: {exc}")


def render_result_card(label: str, value: str) -> None:
    """Render a dark result card for important outputs."""
    st.markdown(
        f"""
        <div class="result-card">
            <div class="result-label">{escape(label)}</div>
            <div class="result-value">{escape(value)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_batch_prediction(model) -> None:
    """Render CSV upload and batch prediction workflow."""
    render_section_header(
        "Bulk workflow",
        "Batch CSV Prediction",
        "Upload a CSV, choose the text column, classify valid rows, and download the result table.",
    )

    uploaded_file = st.file_uploader("Upload CSV file", type=["csv"])

    if uploaded_file is None:
        st.markdown(
            """
            <div class="empty-state">
                Upload a CSV file to preview columns and run batch predictions.
                Results will include predicted labels and confidence scores when available.
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    try:
        df = pd.read_csv(uploaded_file)
    except Exception as exc:
        st.error(f"Could not read uploaded CSV: {exc}")
        return

    if df.empty:
        st.error("Uploaded CSV has no rows.")
        return

    controls_column, preview_column = st.columns([1, 2], gap="large")
    with controls_column:
        text_column = st.selectbox("Text column", options=df.columns.tolist())
        st.metric("Rows detected", f"{len(df):,}")
        run_clicked = st.button(
            "Run Batch Predictions",
            disabled=model is None,
            use_container_width=True,
        )

    with preview_column:
        st.markdown("### CSV Preview")
        st.dataframe(df.head(25), use_container_width=True, hide_index=True)

    if not run_clicked:
        return

    if model is None:
        st.error("Train and save a model before running predictions.")
        return

    try:
        predictions = predict_batch(model, df, text_column)
    except ValueError as exc:
        st.error(str(exc))
        return

    st.markdown("### Prediction Results")
    st.dataframe(predictions, use_container_width=True, hide_index=True)
    st.download_button(
        "Download Predictions CSV",
        data=predictions.to_csv(index=False).encode("utf-8"),
        file_name="text_classifier_predictions.csv",
        mime="text/csv",
        use_container_width=True,
    )


def render_model_performance(metrics: dict[str, Any]) -> None:
    """Render saved evaluation metrics and confusion matrix."""
    render_section_header(
        "Model quality",
        "Performance Overview",
        "Review metrics generated from the held-out evaluation split and inspect the confusion matrix.",
    )

    if not metrics or metrics.get("status") == "not_evaluated":
        st.markdown(
            """
            <div class="empty-state">
                No evaluation metrics have been generated yet. Run
                <code>python -m src.evaluate</code> after training the model.
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    metric_columns = st.columns(4)
    metric_columns[0].metric("Accuracy", _format_metric(metrics.get("accuracy")))
    metric_columns[1].metric(
        "Precision", _format_metric(metrics.get("precision_weighted"))
    )
    metric_columns[2].metric("Recall", _format_metric(metrics.get("recall_weighted")))
    metric_columns[3].metric("F1-score", _format_metric(metrics.get("f1_weighted")))

    report = metrics.get("classification_report")
    if isinstance(report, dict):
        st.markdown("### Classification Report")
        st.dataframe(pd.DataFrame(report).transpose(), use_container_width=True)

    if CONFUSION_MATRIX_PATH.exists():
        st.markdown("### Confusion Matrix")
        st.image(str(CONFUSION_MATRIX_PATH), use_container_width=False)


def render_explainability(model) -> None:
    """Render global feature importance information."""
    render_section_header(
        "Transparent AI",
        "Explainability",
        "Show the words and phrases that influence the classifier so clients can understand the model.",
    )

    if model is None:
        st.markdown(
            """
            <div class="empty-state">
                Train and save a model to view feature explanations.
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    slider_column, copy_column = st.columns([1, 2], gap="large")
    with slider_column:
        top_n = st.slider("Top features per class", min_value=5, max_value=50, value=20)
    with copy_column:
        st.markdown(
            """
            <div class="panel">
                <div class="section-label">Why it matters</div>
                <p class="section-copy">
                    Explanations help turn predictions into conversations:
                    teams can see which terms are driving model behavior and
                    decide whether the output makes business sense.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    try:
        top_features = get_top_features(model, top_n=top_n)
    except (TypeError, ValueError) as exc:
        st.error(f"Could not generate feature explanations: {exc}")
        return

    st.dataframe(top_features, use_container_width=True, hide_index=True)


def render_business_use_case() -> None:
    """Render practical client use cases for the dashboard."""
    render_section_header(
        "Freelance ready",
        "Business Use Cases",
        "A practical dashboard for teams that need fast review, message, and feedback classification.",
    )

    use_cases = [
        (
            "E-commerce stores",
            "Analyze product reviews and surface negative feedback before it becomes a support issue.",
        ),
        (
            "Agencies",
            "Classify campaign comments, survey feedback, and customer messages for reporting.",
        ),
        (
            "Support teams",
            "Prioritize complaint-heavy messages and route urgent feedback faster.",
        ),
        (
            "Small businesses",
            "Filter spam or unwanted messages before they clutter operational inboxes.",
        ),
        (
            "Freelancers",
            "Package a lightweight AI automation service that is understandable and easy to demo.",
        ),
        (
            "Product teams",
            "Turn review exports into quick insight tables for sentiment and follow-up planning.",
        ),
    ]
    cards = "".join(
        f"""
        <div class="use-case-card">
            <strong>{title}</strong>
            <span>{description}</span>
        </div>
        """
        for title, description in use_cases
    )
    st.markdown(f'<div class="use-case-grid">{cards}</div>', unsafe_allow_html=True)


def _format_metric(value: Any) -> str:
    """Format numeric metrics for display."""
    if isinstance(value, (int, float)):
        return f"{value:.2%}"
    return "N/A"


if __name__ == "__main__":
    main()
