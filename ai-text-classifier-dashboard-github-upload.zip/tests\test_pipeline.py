"""Tests for the model training and evaluation pipeline."""

from pathlib import Path

import pandas as pd
import pytest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from src.evaluate import evaluate_model, save_metrics
from src.explain import explain_prediction, get_top_features
from src.train import build_pipeline, train_model


@pytest.fixture()
def sample_training_data() -> pd.DataFrame:
    """Small sentiment dataset with three classes."""
    return pd.DataFrame(
        {
            "text": [
                "great product love it",
                "excellent quality happy",
                "bad product hate it",
                "terrible quality disappointed",
                "okay product average",
                "fine but not special",
                "love this excellent item",
                "awful broken item",
                "average neutral purchase",
                "happy with product",
                "poor bad experience",
                "neutral acceptable item",
            ],
            "label": [
                "positive",
                "positive",
                "negative",
                "negative",
                "neutral",
                "neutral",
                "positive",
                "negative",
                "neutral",
                "positive",
                "negative",
                "neutral",
            ],
        }
    )


def test_build_pipeline_has_expected_steps() -> None:
    """The training pipeline should contain TF-IDF and Logistic Regression."""
    pipeline = build_pipeline()

    assert isinstance(pipeline, Pipeline)
    assert isinstance(pipeline.named_steps["tfidf"], TfidfVectorizer)
    assert isinstance(pipeline.named_steps["classifier"], LogisticRegression)


def test_train_model_fits_pipeline(sample_training_data: pd.DataFrame) -> None:
    """Training should return a fitted Pipeline that can predict."""
    model = train_model(sample_training_data, "text", "label")

    prediction = model.predict(["excellent product"])[0]
    assert prediction in {"positive", "negative", "neutral"}


def test_train_model_rejects_single_class_data() -> None:
    """Training requires at least two labels."""
    df = pd.DataFrame({"text": ["good", "great", "excellent", "nice"], "label": ["positive"] * 4})

    with pytest.raises(ValueError, match="two unique labels"):
        train_model(df, "text", "label")


def test_evaluate_model_returns_real_metrics(sample_training_data: pd.DataFrame) -> None:
    """Evaluation should calculate metrics from model predictions."""
    model = train_model(sample_training_data, "text", "label")
    metrics = evaluate_model(model, sample_training_data["text"], sample_training_data["label"])

    assert 0 <= metrics["accuracy"] <= 1
    assert 0 <= metrics["precision_weighted"] <= 1
    assert 0 <= metrics["recall_weighted"] <= 1
    assert 0 <= metrics["f1_weighted"] <= 1
    assert "classification_report" in metrics
    assert "confusion_matrix" in metrics


def test_save_metrics_writes_json(tmp_path: Path) -> None:
    """Metrics should be saved as JSON."""
    metrics_path = tmp_path / "metrics.json"
    metrics = {"accuracy": 1.0, "labels": ["positive"]}

    save_metrics(metrics, metrics_path)

    assert metrics_path.read_text(encoding="utf-8").startswith("{")


def test_explainability_outputs_dataframes(sample_training_data: pd.DataFrame) -> None:
    """Explainability helpers should return non-empty DataFrames."""
    model = train_model(sample_training_data, "text", "label")

    top_features = get_top_features(model, top_n=3)
    prediction_explanation = explain_prediction(model, "excellent quality product")

    assert not top_features.empty
    assert {"class_label", "feature", "coefficient", "direction"}.issubset(
        top_features.columns
    )
    assert not prediction_explanation.empty
    assert {"feature", "contribution"}.issubset(prediction_explanation.columns)
