"""Simple explainability utilities for TF-IDF text classifiers."""

import logging

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from src.preprocess import clean_text


logger = logging.getLogger(__name__)


def get_top_features(model: Pipeline, top_n: int = 20) -> pd.DataFrame:
    """Return the most influential TF-IDF features for each class.

    For Logistic Regression, positive coefficients indicate features that push
    the model toward a class. In binary classification, this function also shows
    the strongest negative coefficients for the opposite class.

    Args:
        model: Fitted TF-IDF and Logistic Regression pipeline.
        top_n: Number of top features to return per class and direction.

    Returns:
        DataFrame with class labels, feature names, coefficients, and direction.

    Raises:
        ValueError: If ``top_n`` is less than 1.
        TypeError: If the model does not match the expected pipeline structure.
    """
    if top_n < 1:
        raise ValueError("top_n must be at least 1.")

    vectorizer, classifier = _get_supported_steps(model)
    feature_names = vectorizer.get_feature_names_out()
    rows: list[dict[str, object]] = []

    if len(classifier.classes_) == 2 and classifier.coef_.shape[0] == 1:
        negative_class, positive_class = classifier.classes_
        coefficients = classifier.coef_[0]

        rows.extend(
            _feature_rows(
                negative_class,
                feature_names,
                coefficients,
                top_n,
                largest=False,
                direction="negative",
            )
        )
        rows.extend(
            _feature_rows(
                positive_class,
                feature_names,
                coefficients,
                top_n,
                largest=True,
                direction="positive",
            )
        )
    else:
        for class_index, class_label in enumerate(classifier.classes_):
            coefficients = classifier.coef_[class_index]
            rows.extend(
                _feature_rows(
                    class_label,
                    feature_names,
                    coefficients,
                    top_n,
                    largest=True,
                    direction="positive",
                )
            )

    logger.info("Generated top feature explanations with %s rows", len(rows))
    return pd.DataFrame(rows)


def explain_prediction(model: Pipeline, text: str) -> pd.DataFrame:
    """Explain which known TF-IDF features contributed to one prediction.

    Args:
        model: Fitted TF-IDF and Logistic Regression pipeline.
        text: Raw text to explain.

    Returns:
        DataFrame of recognized input features sorted by contribution strength.

    Raises:
        ValueError: If text is empty after cleaning or no known features are found.
        TypeError: If the model does not match the expected pipeline structure.
    """
    vectorizer, classifier = _get_supported_steps(model)
    cleaned_text = clean_text(text)

    if not cleaned_text:
        raise ValueError("Input text is empty after cleaning.")

    transformed_text = vectorizer.transform([cleaned_text])
    non_zero_indices = transformed_text.nonzero()[1]

    if len(non_zero_indices) == 0:
        raise ValueError("No known TF-IDF features were found in the input text.")

    predicted_label = model.predict([cleaned_text])[0]
    class_index = _get_class_index(classifier, predicted_label)
    coefficients = _get_coefficients_for_class(classifier, class_index)
    feature_names = vectorizer.get_feature_names_out()

    rows = []
    for feature_index in non_zero_indices:
        tfidf_value = float(transformed_text[0, feature_index])
        coefficient = float(coefficients[feature_index])
        rows.append(
            {
                "predicted_label": predicted_label,
                "feature": feature_names[feature_index],
                "tfidf_value": round(tfidf_value, 6),
                "class_coefficient": round(coefficient, 6),
                "contribution": round(tfidf_value * coefficient, 6),
            }
        )

    explanation_df = pd.DataFrame(rows).sort_values(
        by="contribution", key=lambda series: series.abs(), ascending=False
    )
    logger.info("Generated prediction explanation with %s rows", len(explanation_df))
    return explanation_df.reset_index(drop=True)


def _get_supported_steps(model: Pipeline) -> tuple[TfidfVectorizer, LogisticRegression]:
    """Extract and validate the expected TF-IDF and Logistic Regression steps."""
    if not isinstance(model, Pipeline):
        raise TypeError(f"Expected a scikit-learn Pipeline, got {type(model).__name__}.")

    try:
        vectorizer = model.named_steps["tfidf"]
        classifier = model.named_steps["classifier"]
    except KeyError as exc:
        raise TypeError("Model must contain 'tfidf' and 'classifier' pipeline steps.") from exc

    if not isinstance(vectorizer, TfidfVectorizer):
        raise TypeError("The 'tfidf' step must be a TfidfVectorizer.")

    if not isinstance(classifier, LogisticRegression):
        raise TypeError("Explainability currently supports LogisticRegression classifiers.")

    if not hasattr(classifier, "coef_"):
        raise TypeError("Classifier must be fitted before explanations can be generated.")

    return vectorizer, classifier


def _feature_rows(
    class_label: object,
    feature_names,
    coefficients,
    top_n: int,
    largest: bool,
    direction: str,
) -> list[dict[str, object]]:
    """Build feature explanation rows from sorted coefficient indices."""
    sorted_indices = coefficients.argsort()
    selected_indices = sorted_indices[-top_n:][::-1] if largest else sorted_indices[:top_n]

    return [
        {
            "class_label": class_label,
            "feature": feature_names[index],
            "coefficient": round(float(coefficients[index]), 6),
            "direction": direction,
        }
        for index in selected_indices
    ]


def _get_class_index(classifier: LogisticRegression, predicted_label: object) -> int:
    """Return the classifier class index for a predicted label."""
    return list(classifier.classes_).index(predicted_label)


def _get_coefficients_for_class(classifier: LogisticRegression, class_index: int):
    """Return coefficients aligned with the predicted class."""
    if len(classifier.classes_) == 2 and classifier.coef_.shape[0] == 1:
        return classifier.coef_[0] if class_index == 1 else -classifier.coef_[0]

    return classifier.coef_[class_index]
