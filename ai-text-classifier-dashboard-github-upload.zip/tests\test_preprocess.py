"""Tests for text preprocessing utilities."""

from pathlib import Path

import pandas as pd
import pytest

from src.preprocess import clean_text, preprocess_dataframe, save_processed_data


def test_clean_text_removes_noise_and_normalizes_case() -> None:
    """Text cleaning should remove common web noise while keeping useful words."""
    text = "<b>GREAT product!!!</b> Email me@test.com or visit https://example.com"

    assert clean_text(text) == "great product!!! email or visit"


def test_clean_text_handles_missing_or_non_string_values() -> None:
    """Missing or non-string text should become an empty string."""
    assert clean_text(None) == ""
    assert clean_text(123) == ""


def test_preprocess_dataframe_drops_missing_rows_and_duplicates() -> None:
    """Preprocessing should clean text, remove invalid rows, and drop duplicates."""
    df = pd.DataFrame(
        {
            "text": [
                "<p>Great product</p>",
                None,
                "Great product",
                "Bad support",
                "   ",
            ],
            "label": ["positive", "negative", "positive", "negative", "neutral"],
        }
    )

    processed = preprocess_dataframe(df, "text", "label")

    assert len(processed) == 2
    assert processed["text"].tolist() == ["great product", "bad support"]
    assert processed["label"].tolist() == ["positive", "negative"]


def test_preprocess_dataframe_raises_for_missing_columns() -> None:
    """A missing required column should raise a clear error."""
    df = pd.DataFrame({"message": ["hello"], "label": ["neutral"]})

    with pytest.raises(ValueError, match="missing required column"):
        preprocess_dataframe(df, "text", "label")


def test_save_processed_data_writes_csv(tmp_path: Path) -> None:
    """Processed data should be saved as a CSV file."""
    df = pd.DataFrame({"text": ["great product"], "label": ["positive"]})
    output_path = tmp_path / "processed.csv"

    save_processed_data(df, output_path)

    saved = pd.read_csv(output_path)
    assert saved.equals(df)


def test_save_processed_data_rejects_empty_dataframe(tmp_path: Path) -> None:
    """Saving an empty processed dataset should fail."""
    with pytest.raises(ValueError, match="empty"):
        save_processed_data(pd.DataFrame(), tmp_path / "processed.csv")
