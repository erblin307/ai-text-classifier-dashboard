# AI Text Classifier Dashboard

A portfolio-ready NLP project for classifying customer reviews and messages with a simple, explainable machine learning pipeline.

The project is built for freelance and small-business use cases: review sentiment analysis, customer feedback classification, complaint detection, and lightweight text automation.

## Business Use Case

Many businesses collect text feedback but do not have a practical way to sort it quickly. This dashboard helps users enter text manually or upload a CSV file, classify each message, view confidence scores, inspect model performance, and explain which words influenced predictions.

Client examples:

- Review sentiment dashboard for e-commerce stores
- Customer feedback classification for agencies
- Complaint detection for support teams
- Product review insights for small businesses
- Spam or unwanted-message filtering workflows
- Support ticket prioritization
- Simple AI automation services for freelancers

## Features

- Manual single-text prediction
- Batch CSV prediction with downloadable results
- Confidence scores for Logistic Regression predictions
- Model performance metrics from real evaluation
- Confusion matrix image generation
- TF-IDF feature explainability
- Per-prediction explanation table
- Modular Python source code
- Pytest test coverage with small in-test datasets
- Streamlit dashboard for business users

## Technologies

- Python
- pandas
- numpy
- scikit-learn
- Streamlit
- matplotlib
- pytest
- joblib
- TF-IDF Vectorizer
- Logistic Regression

## NLP Pipeline

```text
Text cleaning -> TF-IDF vectorization -> Logistic Regression classifier -> prediction -> evaluation -> Streamlit dashboard
```

The project intentionally uses classical, explainable NLP instead of deep learning. This makes it easier to explain to clients, debug, deploy, and extend.

## Dataset

This project is configured for sentiment analysis on customer or product reviews. Bring your own public review dataset as a CSV file and place it in `data/raw/`.

Expected columns:

- `text`: review, message, or feedback text
- `label`: target class such as `positive`, `neutral`, or `negative`

The default processed dataset path used by training is:

```text
data/processed/processed_reviews.csv
```

See [DATA_SOURCES.md](DATA_SOURCES.md) for dataset options and preparation guidance.

## Project Structure

```text
ai-text-classifier-dashboard/
|-- data/
|   |-- raw/
|   |-- processed/
|   `-- sample_uploads/
|-- models/
|-- notebooks/
|-- reports/
|   |-- figures/
|   `-- metrics.json
|-- src/
|   |-- __init__.py
|   |-- config.py
|   |-- data_loader.py
|   |-- preprocess.py
|   |-- train.py
|   |-- evaluate.py
|   |-- predict.py
|   |-- explain.py
|   `-- utils.py
|-- tests/
|   |-- __init__.py
|   |-- test_preprocess.py
|   |-- test_predict.py
|   `-- test_pipeline.py
|-- app.py
|-- requirements.txt
|-- README.md
|-- DATA_SOURCES.md
|-- MODEL_CARD.md
`-- .gitignore
```

## Installation

Create and activate a virtual environment:

```bash
python -m venv .venv
```

On Windows:

```bash
.venv\Scripts\activate
```

If PowerShell blocks activation scripts, run commands through the virtual environment directly:

```bash
.venv\Scripts\python.exe -m streamlit run app.py
```

On macOS or Linux:

```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Data Preparation

Place a raw CSV dataset in `data/raw/`. The project expects configurable text and label columns, with defaults set in [src/config.py](src/config.py):

```python
DEFAULT_TEXT_COLUMN = "text"
DEFAULT_LABEL_COLUMN = "label"
```

Use the preprocessing functions to clean and save the training-ready CSV:

```bash
python -c "from pathlib import Path; from src.data_loader import load_dataset; from src.preprocess import preprocess_dataframe, save_processed_data; df = load_dataset(Path('data/raw/your_dataset.csv')); processed = preprocess_dataframe(df, 'text', 'label'); save_processed_data(processed, Path('data/processed/processed_reviews.csv'))"
```

## Train The Model

Train the TF-IDF and Logistic Regression pipeline:

```bash
python -m src.train
```

This saves the trained model to:

```text
models/text_classifier.joblib
```

## Evaluate The Model

Evaluate the saved model on the deterministic held-out split:

```bash
python -m src.evaluate
```

Evaluation outputs:

```text
reports/metrics.json
reports/figures/confusion_matrix.png
```

Metrics are generated from real predictions. The project does not include fake model metrics.

## Run The Streamlit App

Start the dashboard:

```bash
streamlit run app.py
```

On Windows, this direct command also works without activating the environment:

```bash
.venv\Scripts\python.exe -m streamlit run app.py
```

Then open the local URL shown by Streamlit, usually:

```text
http://localhost:8501
```

The dashboard works best after training and evaluation are complete. If a model or metrics file is missing, the app shows a clear message instead of failing silently.

## Run Tests

Run the full test suite:

```bash
pytest
```

The tests create small sample datasets inside the test files, so they do not require a large external dataset or a saved production model.

## Prediction API Examples

Single text prediction:

```python
from pathlib import Path

from src.predict import load_model, predict_single_text

model = load_model(Path("models/text_classifier.joblib"))
result = predict_single_text(model, "The product quality is excellent.")
print(result)
```

Batch prediction:

```python
from pathlib import Path

import pandas as pd

from src.predict import load_model, predict_batch

model = load_model(Path("models/text_classifier.joblib"))
df = pd.read_csv("data/sample_uploads/customer_reviews.csv")
predictions = predict_batch(model, df, "text")
print(predictions.head())
```

## Explainability

Global feature explanations:

```python
from pathlib import Path

from src.explain import get_top_features
from src.predict import load_model

model = load_model(Path("models/text_classifier.joblib"))
print(get_top_features(model, top_n=20))
```

Single-prediction explanation:

```python
from pathlib import Path

from src.explain import explain_prediction
from src.predict import load_model

model = load_model(Path("models/text_classifier.joblib"))
print(explain_prediction(model, "Excellent quality and fast delivery."))
```

## Screenshots

Add screenshots after training a model and running the dashboard:

- Single Text Prediction tab
- Batch CSV Prediction tab
- Model Performance tab
- Explainability tab
- Business Use Case tab

Suggested location:

```text
reports/figures/
```

## Freelance Client Applications

This project can be adapted into client-facing tools such as:

- Review sentiment dashboard for Shopify, Etsy, or Amazon sellers
- Spam or message filtering for small businesses
- Customer feedback classification for agencies
- Complaint detection for support inboxes
- Product review insights for e-commerce teams
- Support ticket prioritization
- Lightweight AI automation packages for freelancers

## Future Improvements

- Add a FastAPI backend
- Add Docker support
- Add database storage
- Add user authentication
- Add multilingual support
- Add advanced models
- Deploy on Streamlit Cloud
- Add PDF or Excel report export
- Add scheduled retraining
- Add dataset download scripts for selected public datasets

## Responsible Use Notes

This project is intended for workflow support and portfolio demonstration. It should not be used as the only decision-maker for high-risk decisions. Review predictions manually when the result affects customers, payments, support priority, or reputation.
